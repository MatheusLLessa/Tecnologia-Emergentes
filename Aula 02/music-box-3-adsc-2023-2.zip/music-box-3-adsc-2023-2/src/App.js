import api from "./api";
import { useState } from "react";
import "./html-css-template/css/style.css";
import "./html-css-template/css/reset.css";
import Musicas from "./Musicas";


function App() {
  const [musicas, setMusicas] = useState([]);
  // criando state com valor de um vetor vazio;

  function listar() {
  }
  return (
    <>
      <Musicas />
    </>
  );
}
export default App;