import axios from "axios";

const api = axios.create({
  baseURL: "https://6515fcdd09e3260018c950ee.mockapi.io/musicas",
});

export default api;